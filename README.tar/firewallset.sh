#! bin/sh

iptables -t nat -A prerouting_rule -i WAN -p tcp --dport 1723 -j ACCEPT
iptables        -A input_rule      -i WAN -p tcp --dport 1723 -j ACCEPT
iptables        -A output_rule             -p 47               -j ACCEPT
iptables        -A input_rule              -p 47               -j ACCEPT
iptables -A forwarding_rule -i ppp+ -j ACCEPT
iptables -A forwarding_rule -o ppp+ -j ACCEPT
iptables -A input_rule -i ppp+ -j ACCEPT
iptables -A output_rule -o ppp+ -j ACCEPT
iptables -I FORWARD -s 172.16.0.0/24 -j ACCEPT	

