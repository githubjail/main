find | while read filename
do
	if [ -f $filename ]; then
		md5sum $filename >>md5files
	fi
done
